<p>RSUD Gunung Jati Cirebon</p> <h1>{{ $data['kode'] }}</h1> <p>adalah kode verifikasi lupa password anda.</p>
<br>
<p>PENTING : Mohon untuk tidak menyebarkan kode ke orang lain atau pihak RSUD Gunung Jati, Demi Keamanan akun.</p>